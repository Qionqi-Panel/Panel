import unittest
from test.test_json import load_tests

unittest.main()
